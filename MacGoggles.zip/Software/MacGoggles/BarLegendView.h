//
//  BarLegendView.h
//  MacGoggles
//
//  Created by Esten C Hurtle on 4/30/12.
//

#import <Cocoa/Cocoa.h>

@interface BarLegendView : NSView

@end
